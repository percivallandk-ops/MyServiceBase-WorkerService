﻿#環境に合わせて以下の3行は変更してください
#Please change first 3Lines e
######################################

$filePath = "C:\FULLPATH\xxxxx.exe"
$ServiceName = "ServiceName"
$descript = "PreShutdownイベントを受信"

if ($ServiceName -eq "ServiceName") {
    Write-Host "指定が誤っています。処理を中止します。"
    exit 1
}

#####################################

Write-Host "=== MyService デプロイ開始 ==="

Write-Host "サービス停止中..."
sc.exe stop $ServiceName
Start-Sleep -Seconds 2

Write-Host "サービス削除中..."
sc.exe delete $ServiceName
Start-Sleep -Seconds 2

Write-Host "サービス登録中..."
sc.exe create $ServiceName binPath= $filePath start= auto
 Start-Sleep -Seconds 2

Write-Host "サービス説明登録中..."
sc.exe description $descript
Start-Sleep -Seconds 2

Write-Host "サービス起動中..."
sc.exe start $ServiceName
Start-Sleep -Seconds 3

Write-Host "サービス状態:"
sc.exe query $ServiceName

Write-Host ""
Write-Host "=== 完了しました。ENTERキーで終了します ==="
[void][System.Console]::ReadLine()
