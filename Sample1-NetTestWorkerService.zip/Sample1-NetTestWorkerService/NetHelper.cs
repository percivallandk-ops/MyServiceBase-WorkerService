﻿using System;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

public static class NetHelper
{
    private static readonly HttpClient client = new()
    {
        Timeout = TimeSpan.FromMilliseconds(500)
    };

    private static readonly HttpClient postClient = new()
    {
        Timeout = TimeSpan.FromMilliseconds(1000)
    };

    public static bool HttpPostAliveSync_Plain(int count)
    {
        try
        {
            var uri = new Uri("http://httpbin.org/post");
            string payload = $"{{\"count\":{count},\"time\":\"{DateTime.Now:O}\"}}";
            using var content = new StringContent(payload, Encoding.UTF8, "application/json");
            var response = postClient.PostAsync(uri, content).GetAwaiter().GetResult();
            return response.IsSuccessStatusCode;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("http POST error: " + ex.Message, ex);
        }
    }

    public static bool HttpPostAliveSync(int count)
    {
        try
        {
            var uri = new Uri("https://httpbin.org/post");
            string payload = $"{{\"count\":{count},\"time\":\"{DateTime.Now:O}\"}}";
            using var content = new StringContent(payload, Encoding.UTF8, "application/json");
            var response = postClient.PostAsync(uri, content).GetAwaiter().GetResult();
            return response.IsSuccessStatusCode;
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException("https POST error: " + ex.Message, ex);
        }
    }

    public static bool IsNetworkAlive()
    {
        try
        {
            using var ping = new Ping();
            var reply = ping.Send("192.168.1.1", 500);
            return reply.Status == IPStatus.Success;
        }
        catch
        {
            return false;
        }
    }

    public static async Task<bool> IsHttpAlive()
    {
        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Head, "http://www.google.com");
            var response = await client.SendAsync(request);
            return response.IsSuccessStatusCode;
        }
        catch
        {
            return false;
        }
    }
}
