﻿using System.Text;

public static class Helper
{
    private static int DebugMSGLevel;  // 0:例外のみ　1:イベント起動時　2:メソッド出入り
    private static string DebugSVname="";  // サービス名

    private static readonly string LogDirectory = @"C:\ProgramData\MyService";
    private static readonly string LogPath = Path.Combine(LogDirectory, "MyService.log");

    private static readonly object _lock = new object();

    public static void SetDebugMSGLevel(string svname, int level)
    {
        DebugSVname = svname;  // サービス名
        DebugMSGLevel = level;  // 0:例外のみ　1:イベント起動時　2:メソッド出入り
    }

    public static void Write(string message, int level)
    {
        if (level > DebugMSGLevel || level == -1)
        {
            return; // ログレベルが設定より高い場合は出力しない
        }
        try
        {
            if (!Directory.Exists(LogDirectory))
            {
                Directory.CreateDirectory(LogDirectory);
            }

            string line = $"[{DateTime.Now:yyyy/MM/dd HH:mm:ss}] {DebugSVname}  {message}\r\n";

            lock (_lock)
            {
                File.AppendAllText(LogPath, line, Encoding.UTF8);
            }
        }
        catch
        {
            // ログ書き込み失敗時は握りつぶす（サービス停止を防ぐため）
        }
    }
}