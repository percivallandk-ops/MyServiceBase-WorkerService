﻿using Microsoft.Extensions.Hosting;
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

public abstract class MyServiceBase : BackgroundService
{
    private readonly IHostApplicationLifetime lifetime;
    private readonly string serviceName;
    private readonly bool IsPreShutdown;
    private readonly uint preShutdownTimeout;

    private IntPtr statusHandle;
    private HandlerEx handlerDelegate;
    private int stopRequested;
    protected CancellationTokenSource _MyStoppingToken;
    // タスク管理用のコレクションとロックオブジェクト
    private readonly Dictionary<string, Task> _registeredTasks;
    private readonly object _lock = new();

    private bool SyncExecutAsync = false;

    protected MyServiceBase(
        IHostApplicationLifetime lifetime,
        string serviceName,
        bool IsPreShutdown,
        uint preShutdownTimeout)
    {
        this.lifetime = lifetime;
        this.serviceName = serviceName;
        this.IsPreShutdown = IsPreShutdown;
        this.preShutdownTimeout = preShutdownTimeout;
        this._MyStoppingToken = new CancellationTokenSource();
        this._registeredTasks = new();
        this._lock = new();
    }

    //OnStart,OnStop,OnShutdownは同期処理。必要に応じてオーバーライドして使用。
    //OnPreShutdownAsync,RunAsyncは非同期処理。必要に応じてオーバーライドして使用。
    //MSによるとRunAsync はWorker側でオーバーライドが推奨。サービス終了まで継続して実行することが期待される。
    //ユーザー側ではRunAsync内で何もしないのであれば、オーバーライドせずMyServiceBased内で実行して待ってもよい。
    //RunAsync を抜けてしまうとサービスは停止し、サービス一覧でも「停止」となる。

    protected virtual async Task RunAsync(CancellationToken token)
    {
        while (!token.IsCancellationRequested)
        {
            try
            {
                await Task.Delay(2000, token);
            }
            catch (TaskCanceledException)
            {
                Helper.Write("Worker RunAsync Catch signal TaskCanceled", 1);
            }
        }
        Helper.Write("Worker exit RunAsynac", 1);
    }


    protected virtual void OnStart(CancellationToken token) { }
    protected virtual void OnStop(CancellationToken token) { }
    protected virtual void OnShutdown(CancellationToken token) { }

    protected virtual Task OnPreShutdownAsync(CancellationToken token){return Task.CompletedTask;}

    // Worker からタスクを登録するための API
    public void RegisterTasks(params (string name, Task task)[] items)
    {
        if (items == null) return;

        lock (_lock)
        {
            foreach (var (name, task) in items)
            {
                if (task != null && !string.IsNullOrWhiteSpace(name))
                    _registeredTasks[name] = task;
            }
        }
    }
    public void RegisterTask(string name, Task task)
    {
        if (task == null || string.IsNullOrWhiteSpace(name))
            return;

        lock (_lock)
        {
            // 同じ名前が登録されてもそのまま登録する。タスクの重複登録は許容する。
            _registeredTasks[name] = task;
        }
    }
    public class WaitTaskWithTimeout
    {
        /// <summary>
        /// タスク群を待機し、タイムアウトしたら false と未完了タスク名リストを返す。
        /// 全タスクが完了したら true と空リストを返す。
        /// </summary>
        public async Task<(bool Success, List<string> NotCompletedTasks)>
            WhenAll(int timeoutMilliseconds, Dictionary<string, Task> namedTasks)
        {
            if (namedTasks == null || namedTasks.Count == 0)
                return (true, new List<string>());

            // null タスクは除外
            var validTasks = namedTasks
                .Where(kv => kv.Value != null)
                .ToDictionary(kv => kv.Key, kv => kv.Value);

            Task[] taskArray = validTasks.Values.ToArray();

            using var cts = new CancellationTokenSource();

            Task allTasks = Task.WhenAll(taskArray);
            Task timeoutTask = Task.Delay(timeoutMilliseconds, cts.Token);

            Task completed = await Task.WhenAny(allTasks, timeoutTask);

            if (completed == timeoutTask) // タイムアウト発生
            {
                var notCompleted = validTasks
                    .Where(kv => !kv.Value.IsCompleted)
                    .Select(kv => kv.Key)
                    .ToList();
                return (false, notCompleted);
            }
            // WhenAll が先に終わったので timeoutTask をキャンセル
            cts.Cancel();
            // WhenAll の例外は握りつぶす（Canceled/Faulted を許容）
            try
            {
                await allTasks;
            }
            catch
            {
                // ログを出すなら呼び出し側で
            }

            return (true, new List<string>());
        }
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        Helper.Write("ExecuteAsync START", 2);

        RegisterServiceHandler();
        Helper.Write($"IsPreShutdown = {IsPreShutdown}", 2);

        if (IsPreShutdown)
            ConfigurePreShutdownTimeout();

        OnStart(_MyStoppingToken.Token);
        Helper.Write("OnStart Exiting in MyServiceBase.", 2);
        Task workerTask = RunAsync(_MyStoppingToken.Token);
        RegisterTask("RunAsync", workerTask);

        try
        {
            Helper.Write($"RunAsync in", 2);
            await RunAsync(_MyStoppingToken.Token);
            Helper.Write($"RunAsync out", 2);
        }
        catch (Exception ex)
        {
            Helper.Write($"ExecuteAsync exception: {ex.Message}", 0);
            Log($"Handler exception \"{ex}\" in MyServiceBase.");
        }
        finally { }

        // すべてのタスクが終了するのを待つ

        Helper.Write("Awating Async-Task(s) in MyServiceBase.", 2);
        if (_registeredTasks.Count > 0)
        {
            int WaitTimeMs = 8000;
            var waiter = new WaitTaskWithTimeout();  //timeout付き WhenAll
            var (success, notCompleted) =
                await waiter.WhenAll(WaitTimeMs, _registeredTasks);

            if (!success)
            {
                Helper.Write($"{WaitTimeMs}ms Timeout occurred while waiting tasks.", 0);
                foreach (var name in notCompleted)
                {
                    Helper.Write($"Task '{name}' is still running!", 0);
                }
            }
            else
            {
                Helper.Write("All tasks completed.", 2);
            }

            Helper.Write("ALL Task end in MyServiceBase.", 2);
        }
        SyncExecutAsync = true;

    }




    private void RegisterServiceHandler()
    {
        handlerDelegate = Handler;

        statusHandle = RegisterServiceCtrlHandlerEx(
            serviceName,
            handlerDelegate,
            IntPtr.Zero);

        if (statusHandle == IntPtr.Zero)
        {
            Helper.Write("RegisterServiceCtrlHandlerEx failed", 0);
            return;
        }

        SERVICE_STATUS status = new SERVICE_STATUS
        {
            dwServiceType = 0x10,
            dwCurrentState = 0x4,
            dwControlsAccepted =
                SERVICE_ACCEPT_STOP |
                SERVICE_ACCEPT_SHUTDOWN
        };

        if (IsPreShutdown)
            status.dwControlsAccepted |= SERVICE_ACCEPT_PRESHUTDOWN;

        SetServiceStatus(statusHandle, ref status);
        Helper.Write("Service handler registered", 2);
    }

    private void ConfigurePreShutdownTimeout()
    {
        SERVICE_PRESHUTDOWN_INFO info = new SERVICE_PRESHUTDOWN_INFO
        {
            dwPreshutdownTimeout = preShutdownTimeout
        };

        ChangeServiceConfig2(
            statusHandle,
            SERVICE_CONFIG_PRESHUTDOWN_INFO,
            ref info);

        Helper.Write($"PreShutdown timeout set: {preShutdownTimeout}", 2);
    }

    private int Handler(int control, int eventType, IntPtr data, IntPtr context)
    {
        try
        {

            switch (control)
            {
                case SERVICE_CONTROL_STOP:
                    if (Interlocked.Exchange(ref stopRequested, 1) == 1)
                        return 0;
                    Helper.Write("SERVICE_CONTROL_STOP", 1);
                    _MyStoppingToken.Cancel();

                    OnStop(_MyStoppingToken.Token);
                    int _times = 0;
                    while (SyncExecutAsync == false && _times < 8000)
                    {
                        Task.Delay(500).Wait();
                        _times += 500;
                        Helper.Write("Wait SyncExecutAsync to true ", 2);
                    }
                    Helper.Write("SERVICE CLOSE COMPLETED.", 2);
                    lifetime.StopApplication();
                    break;

                case SERVICE_CONTROL_SHUTDOWN:
                    Helper.Write("SERVICE_CONTROL_SHUTDOWN", 1);
                    _MyStoppingToken.Cancel(); // これで全ループに停止シグナルを送る 
                    OnShutdown(_MyStoppingToken.Token);

                    lifetime.StopApplication();
                    break;

                case SERVICE_CONTROL_PRESHUTDOWN:
                    Helper.Write("SERVICE_CONTROL_PRESHUTDOWN", 1);
                    _ = Task.Run(() => HandlePreShutdownAsync(preShutdownTimeout));
                    //lifetime.StopApplication(); と行きたいところだが、非同期＆別タスクのためHandlePreShutdownAsync内で実行

                    break;
            }
        }
        catch (Exception ex)
        {
            Helper.Write($"Handler exception: {ex}", 0);
            Log($"Handler exception \"{ex}\" in MyServiceBase.");
        }
        return 0;
    }

    private const int SERVICE_STOP_PENDING = 0x00000003;
    private const int SERVICE_STOPPED = 0x00000001;

    private const int SERVICE_CONTROL_STOP = 1;
    private const int SERVICE_CONTROL_SHUTDOWN = 5;
    private const int SERVICE_CONTROL_PRESHUTDOWN = 0x0F;

    private const int SERVICE_ACCEPT_STOP = 0x1;
    private const int SERVICE_ACCEPT_SHUTDOWN = 0x4;
    private const int SERVICE_ACCEPT_PRESHUTDOWN = 0x100;

    private const int SERVICE_CONFIG_PRESHUTDOWN_INFO = 7;

    // PreShutdown処理ラッパー。 SCMへ　waitHint　と　checkPoint　を適切に報告しつつ、
    // OnPreShutdownAsyncを呼び出す
    private async Task HandlePreShutdownAsync(uint preShutdowntimeoutMs)
    {
        int waitHintMs = 5000;
        int intervalMs = (int)(waitHintMs * 0.7);
        int checkPoint = 1;
        int callCancelTime = 0;

        if (preShutdowntimeoutMs > 10000) //Timeout指定が10秒以上のとき停止5秒前に送信、そうでないとき2秒前に送信
        {
            callCancelTime = (int)preShutdowntimeoutMs - 5000;
        }
        else callCancelTime = (int)preShutdowntimeoutMs - 2000;

        //using var cts = new CancellationTokenSource(callCancelTime);

        Task workerTask = Task.Run(() => OnPreShutdownAsync(_MyStoppingToken.Token));

        UpdateServiceStatus(SERVICE_STOP_PENDING, waitHintMs, checkPoint);

        Stopwatch sw = new Stopwatch();
        sw.Start();
        try
        {
            while (!workerTask.IsCompleted)
            {
                await Task.Delay(intervalMs, CancellationToken.None);
                checkPoint++;
                UpdateServiceStatus(SERVICE_STOP_PENDING, waitHintMs, checkPoint);

                // タイムアウトに至ってもSCMに延長要請10sまで行う。その間もcheckPointは更新し続ける。
                if (sw.ElapsedMilliseconds > preShutdowntimeoutMs)
                {
                    _MyStoppingToken.Cancel();
                    if (sw.ElapsedMilliseconds - preShutdowntimeoutMs > 8000) //約10秒超過したら強制停止するため10s前で脱出
                    {
                        Helper.Write($"PreShutdown timeout exceeded, forcing stop.", 0);
                        break;
                    }
                }
            }
        }
        catch
        {
            // ignore
        }
        sw.Stop();
        // 一旦待機
        await Task.WhenAny(workerTask, Task.Delay(500));

        // 最後に確実に止める
        Helper.Write($"HandlePreShutdownAsync.lifetime.StopApplication", 2);
        lifetime.StopApplication();
    }


    private void UpdateServiceStatus(int currentState, int waitHint = 0, int checkPoint = 0)
    {
        SERVICE_STATUS status = new SERVICE_STATUS
        {
            dwServiceType = 0x10,
            dwCurrentState = currentState,
            dwControlsAccepted =
                SERVICE_ACCEPT_STOP |
                SERVICE_ACCEPT_SHUTDOWN |
                SERVICE_ACCEPT_PRESHUTDOWN,

            dwWaitHint = waitHint,
            dwCheckPoint = checkPoint
        };

        SetServiceStatus(statusHandle, ref status);
    }

    protected void Log(string message)
    {
        try
        {
            EventLog.WriteEntry(serviceName, message);
        }
        catch { }
    }



    private delegate int HandlerEx(int control, int eventType, IntPtr eventData, IntPtr context);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern IntPtr RegisterServiceCtrlHandlerEx(
        string lpServiceName,
        HandlerEx cbex,
        IntPtr context);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool SetServiceStatus(
        IntPtr handle,
        ref SERVICE_STATUS serviceStatus);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool ChangeServiceConfig2(
        IntPtr hService,
        int dwInfoLevel,
        ref SERVICE_PRESHUTDOWN_INFO lpInfo);

    [StructLayout(LayoutKind.Sequential)]
    private struct SERVICE_STATUS
    {
        public int dwServiceType;
        public int dwCurrentState;
        public int dwControlsAccepted;
        public int dwWin32ExitCode;
        public int dwServiceSpecificExitCode;
        public int dwCheckPoint;
        public int dwWaitHint;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct SERVICE_PRESHUTDOWN_INFO
    {
        public uint dwPreshutdownTimeout;
    }
}
