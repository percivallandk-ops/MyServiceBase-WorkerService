//==============================================
// Key Points for Using MyServiceBase / Worker
//==============================================

// ■ Logging
// Helper.SetDebugMSGLevel(name, level):
//   Set log level (0=exception, 1=basic, 2=verbose, -1=disabled)
// Helper.Write(message, level):
//   Writes logs to "C:\ProgramData\MyService\MyService.log"
//   Output location can be changed (EventLog output is also possible)

// ■ Task Monitoring (optional)
// registerTask(name, task) / registerTasks(...):
//   When a STOP request is issued, waits up to 8 seconds
//   for registered tasks to finish
//   Unfinished task names are logged (possible zombie state)

// ■ CancellationToken (important)
//   token.IsCancellationRequested becomes true on STOP
//   All tasks must monitor this and terminate promptly
//   Pass the token to subtasks from OnStart / OnPreShutdown

// ■ OnStart Notes
//   OnStart must return immediately (no blocking)
//   Actual work should run in asynchronous tasks
//   Delays may cause SCM to treat startup as failed

// ■ SERVICE_NAME (required)
//   Unique service name; shown in SCM, Task Manager, EventLog

// ■ IsPreShutdown / PreShutdownTimeout
//   IsPreShutdown=true → receive PreShutdown
//   false → receive Shutdown (mutually exclusive)
//   PreShutdownTimeout defines wait time (ms); upper limit depends on system

// ■ Overriding OnXXXX()
//   Override only what you need (others have empty defaults)
//   RunAsync() is typically overridden in Worker
//   If unused, RunAsync() may be removed (e.g., Shutdown-only services)
//
// 日本語バージョンの注釈は ./DOC/Worker の注意点まとめ.mdを参照ください

using Microsoft.Extensions.Hosting;
using System.Threading;
using System.Threading.Tasks;

public class MyWorker : MyServiceBase
{
    public const string SERVICE_NAME = "NetTestWorkerService"; //USER SETTING: set your "service name" here.
    public const bool IsPreShutdown = true;             //USER SETTING: set "true" if you want to use OnPreShutdown, otherwise call OnShutdown.
    public const uint PreShutdownTimeout = 20000;       //USER SETTING: set the maximum time for OnPreShutdown to complete in milliseconds.
                                                        //              This is a hint to the OS, not a guarantee.
                                                        //              The OS may have its own upper limit.

    public MyWorker(IHostApplicationLifetime lifetime)
        : base(lifetime, SERVICE_NAME, IsPreShutdown, PreShutdownTimeout)
    {
        Helper.SetDebugMSGLevel(SERVICE_NAME,2);  // 0: errors only, 1: events, 2: verbose, -1 :none
        Helper.Write("Worker constructed", 2);
    }

    protected override void OnStart(CancellationToken Token)
    {
        Helper.Write("Worker OnStart", 2);
    }

    protected override void OnStop(CancellationToken Token)
    {
        Helper.Write("Worker OnStop", 2);
    }

    protected override void OnShutdown(CancellationToken Token)
    {
        //sample code to test shutdown timeout, you can replace it with your actual shutdown code
        Helper.Write("Worker OnShutdown begin loop=5", 0);

   
        for (int i = 0; i < 5; i++)
        {
            try
            {
                bool ok = NetHelper.HttpPostAliveSync_Plain(i);
                Helper.Write($"HTTP-POST(plain)[{i * 1000}] = {(ok ? "Success" : "Fail")}", 0);
                Task.Delay(500).Wait();
            }
            catch (Exception ex)
            {
                Helper.Write($"ERROR: {ex.Message}", 0);
                Helper.Write($"HTTP-POST[{i * 1000}ms] = Fail", 0);
            }

            try
            {
                bool ok2 = NetHelper.HttpPostAliveSync(i);
                Helper.Write($"HTTPS-POST[{i * 1000}ms] = {(ok2 ? "Success" : "Fail")}", 0);
                Task.Delay(500).Wait();
            }
            catch (Exception ex)
            {
                Helper.Write($"ERROR: {ex.Message}", 0);
                Helper.Write($"HTTPS-POST[{i * 1000}ms] = Fail", 0);
            }
        }
        Helper.Write("Worker OnShutdown exit", 0);
    }

    //OnPreShutdownは、安全停止のため設定した最大猶予時間内で処理を完了してください。
    //時間はOS側が持っている上限値あり。30秒目安。上限に達した場合、いずれのフェーズであっても強制停止される。
    //私の環境では40秒くらいだった。必要なら自システムの上限値を事前に把握しておくことをおすすめする。

    //動作概要
    //・OnPreShutdownは、PreShutdownイベントをキャッチ後速やかに非同期で起動される。
    //・設定された最大猶予時間の５秒前（最大猶予時間の設定が10秒以下の場合は2秒前）に
    //CancellationToken（以下Token） により停止要求が通知される。
    //・設定された最大時間で処理が終了しない場合（リターンしない場合）、
    //MyServiceBaseは最大10秒間待機し、その後、OnPreShutdownタスクの強制終了に入る。

    //CancellationTokenの扱いについて
    //これは正直ケースバイケース。
    //私の環境では、短時間で終わる処理ならTokenを見ていなくても特に問題は起きなかった。
    //設定時間内に終了すれば問題ないだろうと思う。
    //処理完了の時間が読めない場合は、対応した方がいいだろう。
    //長めの処理でTokenを無視していると強制終了されるかもしれない。

    //Token対応の実際
    //IsCancellationRequested のfalseからtrueへのターンを監視する。
    //if (IsCancellationRequested) →終了処理へ
    //また、不意のキャンセルに備えOperationCanceledException例外をキャッチする
    //ことをおすすめする。この時点ではなにもできないかもしれないがログくらい残せる。


    protected override async Task OnPreShutdownAsync(CancellationToken token)
    {
        //sample code to test preshutdown timeout. you can replace it with your actual shutdown code
        Helper.Write("Worker OnPreShutdown begin loop=200 Max 10,000ms", 0);
       
        for (int i = 0; i < 200; i++)
        {
           
            try
            {
                bool ok = NetHelper.HttpPostAliveSync_Plain(i);
                Helper.Write($"HTTP-POST(plain)[{i * 1000}] = {(ok ? "Success" : "Fail")}", 0);
                await Task.Delay(500);
            }
            catch (Exception ex)
            {
                Helper.Write($"ERROR: {ex.Message}", 0);
                Helper.Write($"HTTP-POST[{i * 1000}ms] = Fail", 0);
            }

            try
            {
                bool ok2 = NetHelper.HttpPostAliveSync(i);
                Helper.Write($"HTTPS-POST[{i * 1000}ms] = {(ok2 ? "Success" : "Fail")}", 0);
                await Task.Delay(500);
            }
            catch (Exception ex)
            {
                Helper.Write($"ERROR: {ex.Message}", 0);
                Helper.Write($"HTTPS-POST[{i * 1000}ms] = Fail", 0);
            }

            if (token.IsCancellationRequested) //時間が来るといつのまにやらsCancellationRequestedがtrueになるので、ループを抜け終了する
            {
                Helper.Write("[in OnPreShutdownAsync Loop] Catch IsCancellationRequested.", 0);
                break;
            }
        }
        Helper.Write("Worker OnPreShutdown exit.", 0);
        //sample code end
    }

    protected override async Task RunAsync(CancellationToken token)
    {
    
        Helper.Write("RunAsync start", 2);
        while (!token.IsCancellationRequested)
        {
            try
            {
                await Task.Delay(2000, token);
            }
            catch
            {
                if (token.IsCancellationRequested)
                    Helper.Write("[in RunAsync inLOOP] Catch IsCancellationRequested.", 1);
            }
        }
        Helper.Write("RunAsync exit", 2);
    }
}
