//==============================================
// Key Points for Using MyServiceBase / Worker
//==============================================

// ■ Logging
// Helper.SetDebugMSGLevel(name, level):
//   Set log level (0=exception, 1=basic, 2=verbose, -1=disabled)
// Helper.Write(message, level):
//   Writes logs to "C:\ProgramData\MyService\MyService.log"
//   Output location can be changed (EventLog output is also possible)

// ■ Task Monitoring (optional)
// registerTask(name, task) / registerTasks(...):
//   When a STOP request is issued, waits up to 8 seconds
//   for registered tasks to finish
//   Unfinished task names are logged (possible zombie state)

// ■ CancellationToken (important)
//   token.IsCancellationRequested becomes true on STOP
//   All tasks must monitor this and terminate promptly
//   Pass the token to subtasks from OnStart / OnPreShutdown

// ■ OnStart Notes
//   OnStart must return immediately (no blocking)
//   Actual work should run in asynchronous tasks
//   Delays may cause SCM to treat startup as failed

// ■ SERVICE_NAME (required)
//   Unique service name; shown in SCM, Task Manager, EventLog

// ■ IsPreShutdown / PreShutdownTimeout
//   IsPreShutdown=true → receive PreShutdown
//   false → receive Shutdown (mutually exclusive)
//   PreShutdownTimeout defines wait time (ms); upper limit depends on system

// ■ Overriding OnXXXX()
//   Override only what you need (others have empty defaults)
//   RunAsync() is typically overridden in Worker
//   If unused, RunAsync() may be removed (e.g., Shutdown-only services)
//
// 日本語バージョンの注釈は ./DOC/Worker の注意点まとめ.mdを参照ください

using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Intrinsics.X86;
using System.Threading;
using System.Threading.Tasks;

public class MyWorkers : MyServiceBase
{
    // ユーザー設定
    public const string SERVICE_NAME = "CpuLedMonitorService";
    public const bool IsPreShutdown = true; 
    public const uint PreShutdownTimeout = 10000;

    // シリアル通信・CPU監視用メンバ
    private SerialPort? _serialPort;
    bool _serialPortstatus = false;
    private const string PORT_NAME = "COM3";
    private string _portName;
    private readonly Queue<float> _cpuHistory = new();
    private volatile int _latestData; // volatileを付ける
    private Task? _cpuMonitorTask;
    private Task? _OpenSerialPortTask;
    private Task? _SerialPort_Monitor;
    private Task? _SerialPort_AliveSend;
    private readonly object _serialLock = new();


    public MyWorkers(IHostApplicationLifetime lifetime, IConfiguration configuration)
        : base(lifetime, SERVICE_NAME, IsPreShutdown, PreShutdownTimeout)
    {
        _portName = configuration.GetValue<string>("SerialSettings:PortName") ?? "COM3";
        Helper.SetDebugMSGLevel(SERVICE_NAME, 1);
        Helper.Write("Worker constructed", 2);
    }

    protected override void OnStart(CancellationToken MyCancellingToken)
    {
        Helper.Write("Worker OnStart: Launching Monitor Task", 2);

        // SCMに起動完了を即座に返すため、メインロジックを非同期で開始
        _OpenSerialPortTask = Task.Run(() => OpenSerialPortLoopAsync(MyCancellingToken));  //Async Loop1:シリアルポート監視＆接続＆再接続
        _cpuMonitorTask = Task.Run(() => CPU_MonitorLoopAsync(MyCancellingToken));              //Async Loop2:CPUモニター
        _SerialPort_Monitor = Task.Run(() => SerialPort_MonitorLoopAsync(MyCancellingToken));   //Async Loop3:"R"equest監視＆Status送信
        _SerialPort_AliveSend = Task.Run(() => SerialPort_AliveSendAsync(MyCancellingToken));   //Async Loop4:Keep Alive "P"送信
        RegisterTasks(("_OpenSerialPortTask", _OpenSerialPortTask),("_cpuMonitorTask",_cpuMonitorTask),
            ("_SerialPort_Monitor", _SerialPort_Monitor), ("_SerialPort_AliveSend", _SerialPort_AliveSend)); //非同期タスクをMyServiceBaseに登録。見守り用。
        Helper.Write("Worker OnStart: Exit OnStart", 2);
    }
    protected override void OnStop(CancellationToken token)
    {
        Helper.Write("Worker OnStop", 2);
        Helper.Write($"OnSTOP FLG = {token.IsCancellationRequested}", 2);

        try
        {
            if (_serialPort != null)
            {
                if (_serialPort.IsOpen) _serialPort.Close();
                _serialPort.Dispose();
            }
        }
        catch (Exception ex)
        {
            Helper.Write($"Worker OnStop exception: {ex.Message}", 0);
            //Log($"Handler exception \"{ex}\" in MyServiceBase.");
        }


        Helper.Write("Worker OnStop exited", 2);
    }

    /// CPUの監視ループ（非同期実行）
    private async Task CPU_MonitorLoopAsync(CancellationToken token)
    {
        using var cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
        Helper.Write("CPU Monitor Loop Started", 1);

        while (!token.IsCancellationRequested)
        {
            try
            {
                // 2. CPU負荷サンプリング (5秒ごと)
                float currentLoad = cpuCounter.NextValue();
                _cpuHistory.Enqueue(currentLoad);
                if (_cpuHistory.Count > 3) _cpuHistory.Dequeue(); // 直近20秒分(5s * 4)

                float avgLoad = _cpuHistory.Average();
                _latestData = CalculateStatus(avgLoad); // CPU負荷に基づいて0-3のステータスを計算し共有データに保存

                Helper.Write($"CPU Avg: {avgLoad:F1}% -> Status: {_latestData}", 2);

            }
            catch (Exception ex)
            {
                Helper.Write($"CPU Loop Error: {ex.Message}", 0);
                //_serialPort?.Close();
            }

            try { await Task.Delay(5000, token); }      //5s又はtokenでキャンセルされるまで待機
            catch { }     //tokenでキャンセルの場合は例外発生（仕様）。キャンセル例外はwhile条件抵触で抜ける。
    }

        Helper.Write("CPU Monitor Loop Exited", 1);
    }
    private async Task SerialPort_MonitorLoopAsync(CancellationToken token)
    {
        string incoming;

        Helper.Write("SerialPort Monitor Loop Started", 1);

        while (!token.IsCancellationRequested)
        {
            if (_serialPortstatus == true)  // シリアルポートが利用可能？
            {
                try
                {
                    Helper.Write($" TRY Read REQ '{_serialPort.BytesToRead}' Froom ESP32", 2);

                    if (_serialPort.BytesToRead > 0)　// シリアルポートにデータがあるか？（リクエストが来ているか？）
                    {
                        lock (_serialLock) // シリアル通信全体をロックして排他制御
                        {
                            incoming = _serialPort.ReadExisting();
                        }
                        if (incoming.Contains("R"))　// ESP32からのリクエストが"R"を含むか？（Status要求か？）
                        {
                            lock (_serialLock) // 書き込みも同じロックで排他制御
                            {
                                _serialPort.DiscardInBuffer(); // read buufer 古いリクエストを掃除
                                _serialPort.Write(_latestData.ToString()); // 最新のStatusをESP32に送信
                            }
                            Helper.Write($"Send status '{_latestData}' to ESP32", 2);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Helper.Write($"Srial Port Loop Error: {ex.Message}", 0);
                    _serialPort?.Close();
                }
            }

            try {
                await Task.Delay(2000, token);　//2s又はtokenでキャンセルされるまで待機
            }
            catch{ }  //tokenでキャンセルの場合は例外発生（仕様）。キャンセル例外はwhile条件抵触で抜ける。
        }
        Helper.Write("SerialPort Monitor Loop Exited", 1);
    }

    private async Task SerialPort_AliveSendAsync(CancellationToken token)
    {
        Helper.Write("SerialPort Alive Loop Started", 1);

        while (!token.IsCancellationRequested)
        {
            if (_serialPortstatus == true)  // シリアルポートが利用可能？
            {
                try
                {
                    lock (_serialLock) // 読み込みとの排他制御
                    {
                        _serialPort.Write("P");
                    }
                    Helper.Write("Send Alive 'P' to ESP32", 2);
                }
                catch (Exception ex)
                {
                    Helper.Write($"Send Alive 'P'Exceepton:{ex.Message}", 1);
                }
            }

            try
            {
                await Task.Delay(2560, token);          //2.56s又はtokenでキャンセルされるまで待機
            }
            catch { }   //tokenでキャンセルの場合は例外発生（仕様）。キャンセル例外はwhile条件抵触で抜ける。

        }
        Helper.Write("SerialPort Alive Loop Exited", 1);
    }

    private async Task OpenSerialPortLoopAsync(CancellationToken token)
    {
        Helper.Write("OpenSerialPortLoopAsync in", 1);
        if (_portName == null)
        {
            Helper.Write($"Setting file JSON PortName Not Fouund set to Default = {PORT_NAME}", 1);
            _portName = PORT_NAME; // デフォルトにフォールバック 
        }

        while (!token.IsCancellationRequested)
        {

            if (_serialPort == null || _serialPort.IsOpen == false)
            {
                //念のため一旦クローズしてから再作成（特に接続が切れた場合のリセット）
                try
                {
                    if (_serialPort.IsOpen)
                        _serialPort.Close();
                    _serialPort.Dispose();
                }
                catch
                {
                    // ここは失敗しても特に問題ないので無視
                    Helper.Write("OpenSerialPortLoopAsync serialPort Close & Dispose ERROR/No Problrem", 2);
                }

                // 新しいSerialPortインスタンスを作成して接続を試みる

                try
                {
                    _serialPort = new SerialPort(_portName, 115200);

                    if (_serialPort != null)
                    {
                        _serialPort.Open();
                        if (!_serialPort.IsOpen)
                            Helper.Write($"SerialPort {_portName} open ERROR!", 0);
                    }
                    else Helper.Write($"SerialPort {_portName} Create ERROR!", 0);

                    //SerialPort準備完了。バッファをクリアして状態を更新
                    if (_serialPort != null && _serialPort.IsOpen)
                    {
                        Helper.Write($"SerialPort  OpenSTAT {_serialPort.IsOpen} ", 2);
                        Helper.Write($"{_portName} connected.", 1);
                        lock (_serialLock)
                        {
                            _serialPort.DiscardInBuffer();   // 受信バッファ破棄
                            _serialPort.DiscardOutBuffer();  // 送信バッファ破棄
                        }
                        _serialPortstatus = true;　//SerialPort準備完了を他の非同期タスクに通知

                    }
                    else _serialPortstatus = false;　//SerialPort準備失敗

                }
                catch
                {
                    Helper.Write($"{_portName} not connected.", 1);
                    _serialPortstatus = false;
                    // ポートがまだない場合はログを出さず次へ（Verboseなら出してもOK）
                }
            }

            try
            {
                if (_serialPortstatus == false)
                    await Task.Delay(5000, token); //SerialPort準備失敗待機
                else
                    await Task.Delay(20000, token); // 接続成功後は長めに待つ
            }
            catch{ } //tokenでキャンセルの場合は例外発生（仕様）。キャンセル例外はwhile条件抵触で抜ける。

        }
        Helper.Write("OpenSerialPortLoopAsync Loop Exited", 1);

    }

    private int CalculateStatus(float load) => load switch
    {
        > 95 => 3, // 限界
        > 80 => 2, // 高
        > 60 => 1, // 中
        _ => 0     // 低
    };


    protected override void OnShutdown(CancellationToken token)
    {
        Helper.Write("Worker OnShutdown", 1);

    }
    

    //OnPreShutdownは、安全停止のため設定した最大猶予時間内で処理を完了してください。
    //時間はOS側が持っている上限値あり。30秒目安。上限に達した場合、いずれのフェーズであっても強制停止される。
    //私の環境では40秒くらいだった。必要なら自システムの上限値を事前に把握しておくことをおすすめする。

    //動作概要
    //・OnPreShutdownは、PreShutdownイベントをキャッチ後速やかに非同期で起動される。
    //・設定された最大猶予時間の５秒前（最大猶予時間の設定が10秒以下の場合は2秒前）に
    //CancellationToken（以下Token） により停止要求が通知される。
    //・設定された最大時間で処理が終了しない場合（リターンしない場合）、
    //MyServiceBaseは最大10秒間待機し、その後、OnPreShutdownタスクの強制終了に入る。

    //token（token.IsCancellationRequested）の扱いについて
    //これは正直ケースバイケース。
    //私の環境では、短時間で終わる処理ならTokenを見ていなくても特に問題は起きなかった。
    //timeout設定時間内に終了すれば問題ないだろうと思う。
    //矛盾するようだが、タイムアウト以外でも例外が発生することはあり得るため、
    //例外をキャッチすることをおすすめする。
    
    protected override async Task OnPreShutdownAsync(CancellationToken token)
    {
        Helper.Write("Worker OnPreShutdown", 1);
    }
    
    
    protected override async Task RunAsync(CancellationToken token)
    {
        // MyServiceBaseの仕様に合わせて、キャンセルされるまで待機
        while (!token.IsCancellationRequested)
        {
            try
            {
                await Task.Delay(1000, token);
            }
            catch (TaskCanceledException) 
            {
                Helper.Write("Worker RunAsync Catch signal TaskCanceled", 1);
            }
        }
        Helper.Write("Worker exit RunAsynac", 1);
    }
}
   