//==============================================
// Key Points for Using MyServiceBase / Worker
//==============================================

// ■ Logging
// Helper.SetDebugMSGLevel(name, level):
//   Set log level (0=exception, 1=basic, 2=verbose, -1=disabled)
// Helper.Write(message, level):
//   Writes logs to "C:\ProgramData\MyService\MyService.log"
//   Output location can be changed (EventLog output is also possible)

// ■ Task Monitoring (optional)
// registerTask(name, task) / registerTasks(...):
//   When a STOP request is issued, waits up to 8 seconds
//   for registered tasks to finish
//   Unfinished task names are logged (possible zombie state)

// ■ CancellationToken (important)
//   token.IsCancellationRequested becomes true on STOP
//   All tasks must monitor this and terminate promptly
//   Pass the token to subtasks from OnStart / OnPreShutdown

// ■ OnStart Notes
//   OnStart must return immediately (no blocking)
//   Actual work should run in asynchronous tasks
//   Delays may cause SCM to treat startup as failed

// ■ SERVICE_NAME (required)
//   Unique service name; shown in SCM, Task Manager, EventLog

// ■ IsPreShutdown / PreShutdownTimeout
//   IsPreShutdown=true → receive PreShutdown
//   false → receive Shutdown (mutually exclusive)
//   PreShutdownTimeout defines wait time (ms); upper limit depends on system

// ■ Overriding OnXXXX()
//   Override only what you need (others have empty defaults)
//   RunAsync() is typically overridden in Worker
//   If unused, RunAsync() may be removed (e.g., Shutdown-only services)
//
// 日本語バージョンの注釈は ./DOC/Worker の注意点まとめ.mdを参照ください

using Microsoft.Extensions.Hosting;
using System;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

public class MyWorker : MyServiceBase
{
    public const string SERVICE_NAME = "Watcher1";
    private const string TARGET_SERVICE = "NetTestWorkerService";

    public const bool IsPreShutdown = false;
    public const uint PreShutdownTimeout = 30000; // ms

    private bool _intensive = true;

    public MyWorker(IHostApplicationLifetime lifetime)
        : base(lifetime, SERVICE_NAME, IsPreShutdown, PreShutdownTimeout)
    {
        Helper.SetDebugMSGLevel(SERVICE_NAME, 2);
        Helper.Write("Monitor Worker constructed", 1);
    }

    protected override void OnStart(CancellationToken Token)
    {
        Helper.Write("Monitor OnStart", 1);
    }
    protected override void OnStop(CancellationToken Token)
    {
        Helper.Write("Monitor OnStop", 1);
    }

    protected override void OnShutdown(CancellationToken Token)
    {
        Helper.Write("Monitor OnShutdown", 0);
    }

    protected override async Task OnPreShutdownAsync(CancellationToken token)
    {
        Helper.Write("Monitor OnPreShutdown begin → intensive logging ON", 0);

        _intensive = true;

        if (token.IsCancellationRequested)
            Helper.Write("[in OnPreShutdownAsync] IsCancellationRequested.", 0);
        // PreShutdown中はこのタスクは待機だけ
       for (int i= 0; i < 1000; i++)
        {
            if (token.IsCancellationRequested)
                Helper.Write($"[in OnPreShutdownAsync inLoop] Catch IsCancellationRequested. Loop={i}", 0);
            await Task.Delay(500);
        }
        //while (!token.IsCancellationRequested)
        //{
        //    await Task.Delay(500);
        //}

        Helper.Write("Monitor OnPreShutdown end.", 1);
    }

    protected override async Task RunAsync(CancellationToken token)
    {
        Helper.Write("Monitor RunAsync start", 1);
        bool sameFlg = false;
        int  sameCount = 0;
        var pre_status= QueryService(TARGET_SERVICE);

        _intensive = false;
        while (!token.IsCancellationRequested)
        {
            try
            {
                var status = QueryService(TARGET_SERVICE);

                if (status != null)
                {
                    sameFlg = false;
                    if ((status.Value.dwCurrentState != pre_status.Value.dwCurrentState) || 
                        (status.Value.dwCheckPoint != pre_status.Value.dwCheckPoint))
                    {
                        if (sameCount > 0)
                            Helper.Write($"---Same as avobe. cnt={sameCount}", 0);
                        Helper.Write(
                        $"State={status.Value.dwCurrentState} " +
                        $"CheckPoint={status.Value.dwCheckPoint} " +
                        $"WaitHint={status.Value.dwWaitHint}",
                        0);
                        sameCount = 0;
                        pre_status = status;
                    }
                    else
                    {
                        sameCount++;
                    }

                    
                    await Task.Delay(500);
                }
                else
                {
                    if (sameCount > 0)
                    {
                        Helper.Write($"---Same as avobe. cnt={sameCount}", 0);
                        sameCount = 0;
                    }
                    if (!sameFlg)
                    {
                        Helper.Write($"Target service not found", 0);
                        sameFlg = true;
                    }

                }
            }
            catch (Exception ex)
            {
                Helper.Write($"Monitor ERROR: {ex.Message}", 0);
            }

            await Task.Delay(_intensive ? 200 : 1000, token);
            if (token.IsCancellationRequested)
                Helper.Write("[in RunAsync]Catch IsCancellationRequested.", 0);
        }

        Helper.Write("Monitor RunAsync exit", 2);
    }

    // =========================
    // WinAPI
    // =========================

    private const uint SC_MANAGER_CONNECT = 0x0001;
    private const uint SERVICE_QUERY_STATUS = 0x0004;

    [StructLayout(LayoutKind.Sequential)]
    public struct SERVICE_STATUS_PROCESS
    {
        public uint dwServiceType;
        public uint dwCurrentState;
        public uint dwControlsAccepted;
        public uint dwWin32ExitCode;
        public uint dwServiceSpecificExitCode;
        public uint dwCheckPoint;
        public uint dwWaitHint;
        public uint dwProcessId;
        public uint dwServiceFlags;
    }

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern IntPtr OpenSCManager(
        string machineName,
        string databaseName,
        uint dwAccess);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern IntPtr OpenService(
        IntPtr hSCManager,
        string lpServiceName,
        uint dwDesiredAccess);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool QueryServiceStatusEx(
        IntPtr hService,
        int infoLevel,
        out SERVICE_STATUS_PROCESS lpBuffer,
        int cbBufSize,
        out int pcbBytesNeeded);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool CloseServiceHandle(IntPtr hSCObject);

    private SERVICE_STATUS_PROCESS? QueryService(string serviceName)
    {
        IntPtr scm = OpenSCManager(null, null, SC_MANAGER_CONNECT);
        if (scm == IntPtr.Zero) return null;

        IntPtr svc = OpenService(scm, serviceName, SERVICE_QUERY_STATUS);
        if (svc == IntPtr.Zero)
        {
            CloseServiceHandle(scm);
            return null;
        }

        bool ok = QueryServiceStatusEx(
            svc,
            0,
            out SERVICE_STATUS_PROCESS status,
            Marshal.SizeOf<SERVICE_STATUS_PROCESS>(),
            out _);

        CloseServiceHandle(svc);
        CloseServiceHandle(scm);

        if (!ok) return null;

        return status;
    }
}